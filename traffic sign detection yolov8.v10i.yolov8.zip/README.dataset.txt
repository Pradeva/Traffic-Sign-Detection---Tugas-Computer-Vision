# traffic sign detection yolov8 > 2023-07-03 7:04pm
https://universe.roboflow.com/tu-wien-pfowz/traffic-sign-detection-yolov8

Provided by a Roboflow user
License: MIT

